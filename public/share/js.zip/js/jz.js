function GetQueryString(name) {
    var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)')
    var r = window.location.search.substr(1).match(reg) //search,查询？后面的参数，并匹配正则
    if (r != null) return unescape(r[2])
    return null
}

function startBanner(list) {
    for (var i = 0; i < list.length; i++) {
        var html =
            '<div class="swiper-slide">' +
            '<img src="' +
            list[i] +
            '"  class="banner-img"/>' +
            '</div>'
        $('.swiper-wrapper').append(html)
    }

    var swiper = new Swiper('.swiper-container', {
        spaceBetween: 30,
        autoplay: {
            disableOnInteraction: false
        },
        loop: true,
        pagination: {
            el: '.swiper-pagination'
        }
    })
}
$(function() {
    var id = GetQueryString('id')
    var factoryid = GetQueryString('factoryid')
        // console.log(id, factoryid)

    //报名
    $('.baoming-btn').on('click', function() {
        console.log('报名')
    })

    $.post(
        'http://www.dandankj.com/cgi/api/factorys/detail', { id: factoryid },
        function(res) {
            var data = res.data
            console.log(data)

            this.startBanner(data.photos)
            $('.head-img').css('background-image', 'url(' + data.abslogo + ')')
            $('.nickname').text(data.factory_name)
            $('.job').text(data.name)
            $('.job-require').text(
                data.worker_num + ' | ' + data.salary_range + ' | ' + data.age_segment
            )
            $('.head-tip').text(data.tips)
            $('.J30').text(data.address)
        }
    )

    $.post(
        'http://www.dandankj.com/cgi/api/factorys/detail_job', { id: id },
        function(res) {
            var data = res.data
            console.log('job,', res.data)

            if (data.hot == 1) {
                var h = '<span class="status">热招中</span>'
                $('.status').append(h)
            }

            if (data.treatment) {
                var tips = data.treatment.split('，')
                for (var j = 0; j < tips.length; j++) {
                    var t = '<span class="treatment">' + tips[j] + '</span>'
                    $('.wu-tips').append(t)
                }
            }

            $('.money').text('￥' + data.min_price + '-' + data.max_price)
            $('.people').text(data.number_already + '/' + data.number_plan + '人')
            $('.J1').text(data.salary)
            $('.J2').text(data.salary_date)
            $('.J3').text(data.salary_min)
            $('.J4').text(data.salary_stru)
            $('.J5').text(data.food)
            $('.J6').text(data.drom)
            $('.J7').text(data.traffic)
            $('.J8').text(data.contract_explain)
            $('.J9').text(data.wage_payment)
            $('.J10').text(data.insure_explain)
            $('.J11').text(data.work_content)
            $('.J12').text(data.work_explain)
            $('.J13').text(data.work_environment)
            $('.J14').text(data.health_check_explain)
            $('.J15').text(data.idcard_copy)
            $('.J16').text(data.diploma_copy)
            $('.J17').text(data.photo)

            $('.J18').text(data.idcard_explain)
            $('.J19').text(data.diploma_copy)
            $('.J20').text(data.age)
            $('.J21').text(data.tattoo)
            $('.J22').text(data.scar_smoke)
            $('.J23').text(data.factory_again)
            $('.J24').text(data.english)
            $('.J25').text(data.calc)
            $('.J26').text(data.face_dist)
            $('.J27').text(data.clothes)
            $('.J28').text(data.health_check)
            $('.J29').text(data.foreign_body)

            
        }
    )
})